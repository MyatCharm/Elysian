# devcontainer_demo
This is the demo repository for training/testing Machine Learning models using Devcontainer
